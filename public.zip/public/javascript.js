document.addEventListener('DOMContentLoaded', function () {
    const mobileNavToggle = document.querySelector('.mobile-nav-toggle');
    const navList = document.querySelector('nav ul');

    // Remove any restrictions on scrolling
    document.body.style.overflow = 'auto';
    document.documentElement.style.overflow = 'auto';

    mobileNavToggle.addEventListener('click', function () {
        this.classList.toggle('active');
        navList.classList.toggle('active');
    });

    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', () => {
            mobileNavToggle.classList.remove('active');
            navList.classList.remove('active');
        });
    });
});

       // Function to scroll to the top of the page
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth' // This makes the scroll smooth
    });
}

// Show or hide the "back to top" button based on scroll position
window.onscroll = function() {
    let button = document.getElementById("backToTop");
    // If user scrolls down more than 100px, show the button
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        button.style.display = "block"; // Show button
    } else {
        button.style.display = "none"; // Hide button
    }
};


//   sticky header
    window.addEventListener("scroll", function() {
        var scroll = window.scrollY;
        if (scroll >= 50) {
        //     
            document.querySelector("header").classList.add("sticky");
        } else {
            document.querySelector("header").classList.remove("sticky");
        }
    });
    
//  code for slider
   
    document.addEventListener('DOMContentLoaded', function() {
        const slides = document.querySelectorAll('.testimonial-content');
        const dots = document.querySelectorAll('.nav-dot');
        const prevBtn = document.querySelector('.nav-arrow.prev');
        const nextBtn = document.querySelector('.nav-arrow.next');
        let currentSlide = 0;
    
        function showSlide(index) {
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));
            
            slides[index].classList.add('active');
            dots[index].classList.add('active');
        }
    
        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }
    
        function prevSlide() {
            currentSlide = (currentSlide - 1 + slides.length) % slides.length;
            showSlide(currentSlide);
        }
    
        // Event listeners
        nextBtn.addEventListener('click', nextSlide);
        prevBtn.addEventListener('click', prevSlide);
    
        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                currentSlide = index;
                showSlide(currentSlide);
            });
        });
    
        // Auto slide every 5 seconds
        setInterval(nextSlide, 1000);
    });

//   filter for portfolioItems
    document.addEventListener("DOMContentLoaded", function () {
        const filterButtons = document.querySelectorAll(".filter-btn");
        const portfolioItems = document.querySelectorAll(".portfolio-item");
    
        filterButtons.forEach(button => {
            button.addEventListener("click", function () {
                const filter = this.getAttribute("data-filter");
    
                // Remove 'active' class from previous button
                document.querySelector(".filter-btn.active").classList.remove("active");
                this.classList.add("active");
    
                portfolioItems.forEach(item => {
                    // Show the item if it matches the filter or if "all" is selected
                    if (filter === "all" || item.classList.contains(filter)) {
                        item.style.display = "block"; // Show the item
                    } else {
                        item.style.display = "none"; // Hide the item
                    }
                });
            });
        });
    });
    
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("contactForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission
    
            // Show the Thank You message
            let thankYouMessage = document.getElementById("thankYouMessage");
            thankYouMessage.style.display = "block";
    
            // Clear form fields
            this.reset();
    
            // Hide message after 5 seconds
            setTimeout(function() {
                thankYouMessage.style.display = "none";
            }, 3000);
        });
    });


    // count up 

    function animateCounter(counter) {
        const target = +counter.getAttribute("data-target"); // Get target value
        let count = 0;
        const duration = 2000; // Animation duration in milliseconds
        const stepTime = Math.max(duration / target, 10); // Time per step

        function updateCount() {
            count += Math.ceil(target / (duration / stepTime)); // Increment count smoothly
            counter.innerText = count;

            if (count < target) {
                requestAnimationFrame(updateCount);
            } else {
                counter.innerText = target; // Ensure it ends exactly at target
            }
        }

        updateCount();
    }

    window.onload = function () {
        document.querySelectorAll(".counter").forEach(counter => {
            animateCounter(counter);
        });
    };